$('.glyphicon-menu-hamburger').click(function(){
  $('nav.mainmenu').toggleClass('show');
});
